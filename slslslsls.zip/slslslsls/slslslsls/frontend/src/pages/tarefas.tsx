import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Loader2, Check, Calendar, User } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Task, User as UserType, Project } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { Checkbox } from "@/components/ui/checkbox";

export default function Tarefas() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    titulo: "",
    descricao: "",
    assignedToId: "",
    projectId: "",
    dataVencimento: "",
  });

  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: users } = useQuery<UserType[]>({
    queryKey: ["/api/users"],
  });

  const { data: projects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({ title: "Tarefa criada com sucesso!" });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar tarefa",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: (data: { id: string; status: string }) =>
      apiRequest("PUT", `/api/tasks/${data.id}/status`, { status: data.status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({ title: "Status atualizado!" });
    },
  });

  const resetForm = () => {
    setFormData({
      titulo: "",
      descricao: "",
      assignedToId: "",
      projectId: "",
      dataVencimento: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSubmit = {
      ...formData,
      projectId: formData.projectId === "none" ? "" : formData.projectId,
    };
    createMutation.mutate(dataToSubmit);
  };

  const handleToggleStatus = (task: Task) => {
    const newStatus = task.status === "pendente" ? "concluida" : "pendente";
    toggleMutation.mutate({ id: task.id, status: newStatus });
  };

  const getUserName = (id: string) => users?.find((u) => u.id === id)?.nome || "Desconhecido";
  const getProjectTitle = (id: string | null) => projects?.find((p) => p.id === id)?.titulo || "Sem projeto";

  const canCreateTasks = user?.role === "admin" || user?.role === "gerente";

  const myTasks = tasks?.filter((task) => task.assignedToId === user?.id);
  const allTasks = tasks;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 bg-gradient-to-br from-slate-50 via-purple-50/30 to-blue-50/30 dark:from-slate-950 dark:via-purple-950/20 dark:to-blue-950/20 min-h-screen">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 dark:from-purple-400 dark:via-pink-400 dark:to-blue-400 bg-clip-text text-transparent">
            Tarefas
          </h1>
          <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base">Gerencie e acompanhe suas tarefas diárias</p>
        </div>
        {canCreateTasks && (
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button 
                data-testid="button-nova-tarefa"
                className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 text-white font-semibold shadow-xl shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 relative overflow-hidden group"
              >
                {/* Shimmer effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
                <Plus className="mr-2 h-4 w-4 relative z-10" />
                <span className="relative z-10">Nova Tarefa</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Nova Tarefa</DialogTitle>
                <DialogDescription>
                  Atribua uma tarefa para um membro da equipe
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="titulo">Título *</Label>
                  <Input
                    id="titulo"
                    value={formData.titulo}
                    onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                    required
                    data-testid="input-titulo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="descricao">Descrição</Label>
                  <Textarea
                    id="descricao"
                    value={formData.descricao}
                    onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                    rows={3}
                    data-testid="input-descricao"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="assignedToId">Atribuir para *</Label>
                  <Select value={formData.assignedToId} onValueChange={(value) => setFormData({ ...formData, assignedToId: value })}>
                    <SelectTrigger data-testid="select-usuario">
                      <SelectValue placeholder="Selecione um usuário" />
                    </SelectTrigger>
                    <SelectContent>
                      {users?.map((u) => (
                        <SelectItem key={u.id} value={u.id}>
                          {u.nome} ({u.role})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="projectId">Projeto (opcional)</Label>
                  <Select value={formData.projectId} onValueChange={(value) => setFormData({ ...formData, projectId: value })}>
                    <SelectTrigger data-testid="select-projeto">
                      <SelectValue placeholder="Selecione um projeto" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Nenhum</SelectItem>
                      {projects?.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.titulo}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataVencimento">Data de Vencimento</Label>
                  <Input
                    id="dataVencimento"
                    type="date"
                    value={formData.dataVencimento}
                    onChange={(e) => setFormData({ ...formData, dataVencimento: e.target.value })}
                    data-testid="input-vencimento"
                  />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending} data-testid="button-salvar-tarefa">
                    {createMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Criando...
                      </>
                    ) : (
                      "Criar Tarefa"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold">Minhas Tarefas</h2>
            <p className="text-sm text-muted-foreground">Tarefas atribuídas a você</p>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : myTasks && myTasks.length > 0 ? (
              <div className="space-y-3">
                {myTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-start gap-3 p-4 rounded-lg border hover-elevate"
                    data-testid={`task-${task.id}`}
                  >
                    <Checkbox
                      checked={task.status === "concluida"}
                      onCheckedChange={() => handleToggleStatus(task)}
                      className="mt-1"
                      data-testid={`checkbox-${task.id}`}
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className={`font-medium ${task.status === "concluida" ? "line-through text-muted-foreground" : ""}`}>
                        {task.titulo}
                      </h3>
                      {task.descricao && (
                        <p className="text-sm text-muted-foreground mt-1">{task.descricao}</p>
                      )}
                      <div className="flex flex-wrap gap-2 mt-2">
                        {task.projectId && (
                          <Badge variant="outline" className="text-xs">
                            {getProjectTitle(task.projectId)}
                          </Badge>
                        )}
                        {task.dataVencimento && (
                          <Badge variant="outline" className="text-xs">
                            <Calendar className="h-3 w-3 mr-1" />
                            {new Date(task.dataVencimento).toLocaleDateString("pt-BR")}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">Nenhuma tarefa atribuída</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold">Todas as Tarefas</h2>
            <p className="text-sm text-muted-foreground">Visão geral de todas as tarefas</p>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : allTasks && allTasks.length > 0 ? (
              <div className="space-y-3">
                {allTasks.map((task) => (
                  <div
                    key={task.id}
                    className="p-4 rounded-lg border hover-elevate"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <h3 className={`font-medium ${task.status === "concluida" ? "line-through text-muted-foreground" : ""}`}>
                          {task.titulo}
                        </h3>
                        <div className="flex items-center gap-2 mt-2">
                          <User className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">
                            {getUserName(task.assignedToId)}
                          </span>
                        </div>
                      </div>
                      <Badge className={task.status === "concluida" ? "bg-green-500" : "bg-muted"}>
                        {task.status === "concluida" ? "Concluída" : "Pendente"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">Nenhuma tarefa criada</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
