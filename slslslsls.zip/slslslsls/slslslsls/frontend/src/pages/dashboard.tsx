import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, FolderKanban, DollarSign, CheckSquare, TrendingUp, TrendingDown, Clock, Activity, BarChart3 } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<any>({
    queryKey: ["/api/dashboard/stats"],
  });

  const COLORS = {
    primary: "#8b5cf6",
    secondary: "#a855f7",
    success: "#10b981", 
    warning: "#f59e0b",
    danger: "#ef4444",
    purple: "#8b5cf6",
    blue: "#3b82f6",
    cyan: "#06b6d4",
    pink: "#ec4899",
    emerald: "#10b981",
    gray: "#6b7280"
  };

  const statCards = [
    {
      title: "Total de Clientes",
      value: stats?.totalClients || 0,
      icon: Users,
      iconColor: "text-blue-600",
      iconBg: "bg-blue-100 dark:bg-blue-950",
      trend: "+12.5%",
      trendUp: true,
      description: "vs mês anterior"
    },
    {
      title: "Projetos Ativos",
      value: stats?.activeProjects || 0,
      icon: FolderKanban,
      iconColor: "text-purple-600",
      iconBg: "bg-purple-100 dark:bg-purple-950",
      trend: "+8.3%",
      trendUp: true,
      description: "em andamento"
    },
    {
      title: "Tarefas Pendentes",
      value: stats?.pendingTasks || 0,
      icon: CheckSquare,
      iconColor: "text-orange-600",
      iconBg: "bg-orange-100 dark:bg-orange-950",
      trend: "-5.2%",
      trendUp: false,
      description: "aguardando conclusão"
    },
    {
      title: "Faturamento Total",
      value: new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
      }).format(stats?.totalRevenue || 0),
      icon: DollarSign,
      iconColor: "text-emerald-600",
      iconBg: "bg-emerald-100 dark:bg-emerald-950",
      trend: "+23.7%",
      trendUp: true,
      description: "receitas este ano"
    },
  ];

  if (isLoading) {
    return (
      <div className="p-6 lg:p-8 space-y-6 bg-slate-50 dark:bg-slate-950 min-h-screen">
        <div className="space-y-2">
          <Skeleton className="h-9 w-64" />
          <Skeleton className="h-5 w-96" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="border border-slate-200 dark:border-slate-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-10 w-10 rounded-lg" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-20" />
                <Skeleton className="h-4 w-32 mt-2" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 bg-gradient-to-br from-slate-50 via-purple-50/30 to-blue-50/30 dark:from-slate-950 dark:via-purple-950/20 dark:to-blue-950/20 min-h-screen">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-600 to-blue-600 dark:from-purple-400 dark:to-blue-400 bg-clip-text text-transparent">
          Dashboard Executivo
        </h1>
        <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base">
          Visão geral e análise de desempenho em tempo real
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        {statCards.map((card, index) => (
          <Card 
            key={card.title}
            className="border border-slate-200/50 dark:border-slate-800/50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl hover:shadow-2xl hover:shadow-purple-500/10 dark:hover:shadow-purple-500/20 transition-all duration-300 hover:scale-105 animate-slide-in-bottom"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-400">
                {card.title}
              </CardTitle>
              <div className={`p-2.5 rounded-lg ${card.iconBg}`}>
                <card.icon className={`h-5 w-5 ${card.iconColor}`} />
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                {card.value}
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className={`flex items-center gap-1 font-semibold ${
                  card.trendUp 
                    ? 'text-emerald-600 dark:text-emerald-400' 
                    : 'text-red-600 dark:text-red-400'
                }`}>
                  {card.trendUp ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  {card.trend}
                </div>
                <span className="text-slate-500 dark:text-slate-500">
                  {card.description}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid gap-3 sm:gap-4 lg:grid-cols-2">
        {/* Faturamento Mensal */}
        <Card className="border border-slate-200/50 dark:border-slate-800/50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden chart-card-animate chart-glow">
          <CardHeader className="border-b border-slate-200/50 dark:border-slate-800/50 bg-gradient-to-r from-purple-500/5 to-blue-500/5 dark:from-purple-500/10 dark:to-blue-500/10">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-950">
                <TrendingUp className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                  Faturamento Mensal
                </CardTitle>
                <CardDescription>
                  Evolução das receitas nos últimos 6 meses
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 hide-scrollbar chart-animate">
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={stats?.monthlyRevenue || []} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={COLORS.purple} stopOpacity={0.4}/>
                    <stop offset="95%" stopColor={COLORS.purple} stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="purpleGradient" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="50%" stopColor="#a855f7" />
                    <stop offset="100%" stopColor="#3b82f6" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" className="dark:stroke-slate-800/30" opacity={0.3} />
                <XAxis 
                  dataKey="mes" 
                  stroke="#94a3b8"
                  style={{ fontSize: '11px', fontWeight: 600 }}
                  tick={{ fill: '#94a3b8' }}
                />
                <YAxis 
                  stroke="#94a3b8"
                  style={{ fontSize: '11px', fontWeight: 600 }}
                  tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                  tick={{ fill: '#94a3b8' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "rgba(15, 23, 42, 0.95)",
                    border: "1px solid rgba(139, 92, 246, 0.3)",
                    borderRadius: "12px",
                    boxShadow: "0 10px 25px -5px rgb(0 0 0 / 0.3)",
                    backdropFilter: "blur(10px)",
                    color: "#fff"
                  }}
                  formatter={(value: any) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Faturamento']}
                  labelStyle={{ color: '#a855f7', fontWeight: 'bold' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="valor" 
                  stroke="url(#purpleGradient)"
                  strokeWidth={4}
                  dot={{ fill: COLORS.purple, strokeWidth: 3, r: 6, stroke: "#fff" }}
                  activeDot={{ r: 8, strokeWidth: 3, fill: COLORS.purple }}
                  fill="url(#colorRevenue)"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Status dos Projetos */}
        <Card className="border border-slate-200/50 dark:border-slate-800/50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden chart-card-animate chart-glow" style={{ animationDelay: '0.1s' }}>
          <CardHeader className="border-b border-slate-200/50 dark:border-slate-800/50 bg-gradient-to-r from-purple-500/5 to-pink-500/5 dark:from-purple-500/10 dark:to-pink-500/10">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-950">
                <Activity className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                  Status dos Projetos
                </CardTitle>
                <CardDescription>
                  Distribuição por fase de execução
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 hide-scrollbar chart-animate">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <defs>
                  <linearGradient id="pieGrad1" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor={COLORS.gray} />
                    <stop offset="100%" stopColor="#9ca3af" />
                  </linearGradient>
                  <linearGradient id="pieGrad2" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor={COLORS.purple} />
                    <stop offset="100%" stopColor={COLORS.blue} />
                  </linearGradient>
                  <linearGradient id="pieGrad3" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor={COLORS.emerald} />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>
                <Pie
                  data={stats?.projectsByStatus || []}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value, percent }) => 
                    `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                  }
                  outerRadius={95}
                  innerRadius={40}
                  fill="#8884d8"
                  dataKey="value"
                  strokeWidth={3}
                  stroke="rgba(255,255,255,0.1)"
                >
                  {(stats?.projectsByStatus || []).map((entry: any, index: number) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={index === 0 ? 'url(#pieGrad1)' : index === 1 ? 'url(#pieGrad2)' : 'url(#pieGrad3)'} 
                    />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "rgba(15, 23, 42, 0.95)",
                    border: "1px solid rgba(139, 92, 246, 0.3)",
                    borderRadius: "12px",
                    boxShadow: "0 10px 25px -5px rgb(0 0 0 / 0.3)",
                    backdropFilter: "blur(10px)",
                    color: "#fff"
                  }}
                  labelStyle={{ color: '#a855f7', fontWeight: 'bold' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Horas Trabalhadas */}
        <Card className="border border-slate-200/50 dark:border-slate-800/50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden chart-card-animate chart-glow" style={{ animationDelay: '0.2s' }}>
          <CardHeader className="border-b border-slate-200/50 dark:border-slate-800/50 bg-gradient-to-r from-orange-500/5 to-amber-500/5 dark:from-orange-500/10 dark:to-amber-500/10">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-100 dark:bg-orange-950">
                <Clock className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                  Horas Trabalhadas
                </CardTitle>
                <CardDescription>
                  Produtividade da equipe por colaborador
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 hide-scrollbar chart-animate">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={stats?.hoursByUser || []} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.warning} stopOpacity={1}/>
                    <stop offset="100%" stopColor="#f97316" stopOpacity={0.7}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" className="dark:stroke-slate-800/30" opacity={0.3} />
                <XAxis 
                  dataKey="nome" 
                  stroke="#94a3b8"
                  style={{ fontSize: '11px', fontWeight: 600 }}
                  tick={{ fill: '#94a3b8' }}
                />
                <YAxis 
                  stroke="#94a3b8"
                  style={{ fontSize: '11px', fontWeight: 600 }}
                  tickFormatter={(value) => `${value}h`}
                  tick={{ fill: '#94a3b8' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "rgba(15, 23, 42, 0.95)",
                    border: "1px solid rgba(249, 115, 22, 0.3)",
                    borderRadius: "12px",
                    boxShadow: "0 10px 25px -5px rgb(0 0 0 / 0.3)",
                    backdropFilter: "blur(10px)",
                    color: "#fff"
                  }}
                  formatter={(value: any) => [`${value} horas`, 'Horas Trabalhadas']}
                  labelStyle={{ color: '#fb923c', fontWeight: 'bold' }}
                />
                <Bar 
                  dataKey="horas" 
                  fill="url(#barGradient)"
                  radius={[12, 12, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Receitas vs Despesas */}
        <Card className="border border-slate-200/50 dark:border-slate-800/50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden chart-card-animate chart-glow" style={{ animationDelay: '0.3s' }}>
          <CardHeader className="border-b border-slate-200/50 dark:border-slate-800/50 bg-gradient-to-r from-emerald-500/5 to-green-500/5 dark:from-emerald-500/10 dark:to-green-500/10">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100 dark:bg-emerald-950">
                <BarChart3 className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                  Receitas vs Despesas
                </CardTitle>
                <CardDescription>
                  Análise financeira comparativa mensal
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 hide-scrollbar chart-animate">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={stats?.financialOverview || []} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="receitasGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.success} stopOpacity={1}/>
                    <stop offset="100%" stopColor="#059669" stopOpacity={0.7}/>
                  </linearGradient>
                  <linearGradient id="despesasGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.danger} stopOpacity={1}/>
                    <stop offset="100%" stopColor="#dc2626" stopOpacity={0.7}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" className="dark:stroke-slate-800/30" opacity={0.3} />
                <XAxis 
                  dataKey="mes" 
                  stroke="#94a3b8"
                  style={{ fontSize: '11px', fontWeight: 600 }}
                  tick={{ fill: '#94a3b8' }}
                />
                <YAxis 
                  stroke="#94a3b8"
                  style={{ fontSize: '11px', fontWeight: 600 }}
                  tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                  tick={{ fill: '#94a3b8' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "rgba(15, 23, 42, 0.95)",
                    border: "1px solid rgba(16, 185, 129, 0.3)",
                    borderRadius: "12px",
                    boxShadow: "0 10px 25px -5px rgb(0 0 0 / 0.3)",
                    backdropFilter: "blur(10px)",
                    color: "#fff"
                  }}
                  formatter={(value: any) => `R$ ${value.toLocaleString('pt-BR')}`}
                  labelStyle={{ color: '#10b981', fontWeight: 'bold' }}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '15px' }}
                  iconType="circle"
                />
                <Bar 
                  dataKey="receitas" 
                  name="Receitas" 
                  fill="url(#receitasGradient)"
                  radius={[12, 12, 0, 0]}
                />
                <Bar 
                  dataKey="despesas" 
                  name="Despesas" 
                  fill="url(#despesasGradient)"
                  radius={[12, 12, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
