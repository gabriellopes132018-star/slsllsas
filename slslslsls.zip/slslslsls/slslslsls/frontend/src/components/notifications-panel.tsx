import { useQuery } from "@tanstack/react-query";
import { Bell, X, AlertCircle, CheckCircle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface Announcement {
  id: string;
  titulo: string;
  mensagem: string;
  targetRole: string | null;
  createdAt: string;
}

export function NotificationsPanel() {
  const [open, setOpen] = useState(false);

  const { data: announcements = [] } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    refetchInterval: 30000,
  });

  const unreadCount = announcements.length;

  const getIcon = (index: number) => {
    const icons = [CheckCircle, AlertCircle, Info];
    return icons[index % icons.length];
  };

  const getIconColor = (index: number) => {
    const colors = [
      "text-emerald-500",
      "text-amber-500",
      "text-blue-500",
    ];
    return colors[index % colors.length];
  };

  const getIconBg = (index: number) => {
    const bgs = [
      "bg-emerald-500/10",
      "bg-amber-500/10",
      "bg-blue-500/10",
    ];
    return bgs[index % bgs.length];
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative hover:bg-white/5 transition-all duration-300 group"
        >
          <Bell className="h-5 w-5 text-slate-300 group-hover:text-white transition-colors" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-gradient-to-r from-pink-500 to-purple-500 border-0 text-[10px] font-bold animate-pulse-glow">
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="w-96 p-0 bg-slate-900/95 backdrop-blur-xl border-slate-700/50 shadow-2xl animate-scale-in"
        align="end"
      >
        <CardHeader className="border-b border-slate-700/50 bg-gradient-to-r from-purple-500/10 to-blue-500/10">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Bell className="h-5 w-5 text-purple-400" />
              Notificações
            </CardTitle>
            {unreadCount > 0 && (
              <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white border-0">
                {unreadCount} {unreadCount === 1 ? "nova" : "novas"}
              </Badge>
            )}
          </div>
        </CardHeader>
        <ScrollArea className="h-[400px]">
          <CardContent className="p-0">
            {announcements.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                <Bell className="h-12 w-12 mb-3 opacity-50" />
                <p className="text-sm">Nenhuma notificação</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-700/30">
                {announcements.map((announcement, index) => {
                  const Icon = getIcon(index);
                  const iconColor = getIconColor(index);
                  const iconBg = getIconBg(index);

                  return (
                    <div
                      key={announcement.id}
                      className="p-4 hover:bg-white/5 transition-colors cursor-pointer group animate-slide-in-bottom"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <div className="flex gap-3">
                        <div className={`flex-shrink-0 p-2 rounded-lg ${iconBg} group-hover:scale-110 transition-transform`}>
                          <Icon className={`h-5 w-5 ${iconColor}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h4 className="text-sm font-semibold text-white truncate">
                              {announcement.titulo}
                            </h4>
                            {announcement.targetRole && (
                              <Badge
                                variant="outline"
                                className="flex-shrink-0 text-xs border-slate-600 text-slate-400"
                              >
                                {announcement.targetRole}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-300 line-clamp-2 mb-2">
                            {announcement.mensagem}
                          </p>
                          <p className="text-xs text-slate-500">
                            {formatDistanceToNow(new Date(announcement.createdAt), {
                              addSuffix: true,
                              locale: ptBR,
                            })}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
