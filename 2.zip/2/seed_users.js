import bcrypt from 'bcrypt';
import { Pool } from '@neondatabase/serverless';
import ws from 'ws';
import { neonConfig } from '@neondatabase/serverless';

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function seedUsers() {
  const client = await pool.connect();
  try {
    // Check if users already exist
    const existingUsers = await client.query('SELECT COUNT(*) FROM users');
    if (existingUsers.rows[0].count > 0) {
      console.log('✅ Usuários já existem no banco de dados');
      return;
    }

    // Create default users
    const defaultPassword = await bcrypt.hash('admin123', 10);
    
    await client.query(`
      INSERT INTO users (username, password, nome, email, role)
      VALUES 
        ('admin', $1, 'Administrador', 'admin@lopesdesigner.com', 'admin'),
        ('gerente', $1, 'Gerente Geral', 'gerente@lopesdesigner.com', 'gerente'),
        ('funcionario', $1, 'Funcionário Teste', 'funcionario@lopesdesigner.com', 'funcionario')
    `, [defaultPassword]);

    console.log('✅ Usuários de teste criados com sucesso!');
    console.log('   - admin / admin123');
    console.log('   - gerente / admin123');
    console.log('   - funcionario / admin123');
  } catch (error) {
    console.error('❌ Erro ao criar usuários:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

seedUsers();
